extends Resource
